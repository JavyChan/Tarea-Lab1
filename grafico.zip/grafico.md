```python
import numpy as np
import matplotlib.pyplot as plt
```


```python
datos = np.genfromtxt('masa-desp.txt')

realmass=datos[:,1]
dmass=datos[:,3]
displacement=datos[:,2]
ddisp=datos[:,4]
print(realmass,displacement)
print(dmass,ddisp)
```

    [ 249.8  499.4  749.2  999.2 1249.  1486.6 1748.4] [ 8.8 16.2 24.1 32.4 40.5 48.2 56. ]
    [0.1 0.1 0.1 0.1 0.1 0.1 0.1] [0.1  0.05 0.05 0.05 0.3  0.05 0.05]
    


```python
plt.style.use("bmh")
plt.figure(figsize=(12,8))

plt.xlabel('Masa [g]')
plt.xlim(0,1800)

plt.ylabel('Desplazamiento [cm]')
plt.ylim(0,60)

x = np.array([0,250,500,750,1000,1250,1500,1750,2000])
y = lambda x: (2**(-4)-2**(-6)-2**(-7)-2**(-8))*x
plt.plot(x, y(x),color = 'purple')

plt.errorbar(realmass,displacement,yerr=ddisp,xerr=dmass,fmt='none',ecolor='red')

plt.scatter(realmass,displacement)
plt.grid(True)
plt.savefig('grafico1.pdf')

plt.show()
```


    
![png](output_2_0.png)
    



```python
# Cambiar escala: plt.[]scale('log')

## Para hacer plots uno al lado de otro: plt.subplot(1,2,1)
```

Busqueda binaria para la constante 1/k (pendiente=g/m, dividimos por g inmediatamente)

Iteraciones 
1) 2^-5
2) 2^-5+2^-11
3) 2^-5+
14) ((2^{-5}+2^{-11}+2^{-12}+2^{-13}+2^{-14}))
...

Final:
\begin{align*}
    \frac{1}{k}&\approx\frac{(2^{(-2)}+2^{(-4)}+2^{(-8)})}{9.81}\\
    &=0.03225344036\\
    \implies k &= 31.0044444444
\end{align*}


```python
float(((2**(-5)+2**(-11)+2**(-12)+2**(-13)+2**(-14))))
```




    0.03216552734375




```python
9.81/(2**(-4)-2**(-6)-2**(-7)-2**(-8))
```




    279.04




```python
(313.9+279.04)/2
```




    296.47




```python
313.9-296.47
```




    17.42999999999995



Extra: valores $k_i$ (gracias ChatGPT)


```python
# Valores de masas en kg (con sus incertidumbres)
delta_m = [249.8, 499.4, 749.2, 999.2, 1249.0, 1486.6, 1748.4]  # en gramos
delta_m_err = [0.1, 0.1, 0.2, 0.1, 0.2, 0.2, 0.3]  # incertidumbre en gramos

# Convertimos las masas de gramos a kilogramos
delta_m = [m / 1000 for m in delta_m]
delta_m_err = [err / 1000 for err in delta_m_err]

# Valores de desplazamientos (con sus incertidumbres)
y = [8.8, 16.2, 24.1, 32.4, 40.5, 48.2, 56.0]  # en cm
y_err = [0.1, 0.05, 0.05, 0.05, 0.3, 0.05, 0.05]  # incertidumbre en cm

# Convertimos los desplazamientos de cm a metros
y = [yi / 100 for yi in y]
y_err = [err / 100 for err in y_err]

# Valor de g (en m/s^2)
g = 9.81

# Cálculo de k = (Delta m * g) / y
k = [(delta_m[i] * g) / y[i] for i in range(len(delta_m))]

# Imprimir resultados
for i, ki in enumerate(k):
    print(f"k_{i+1} = {ki:.4f} N/m")

```

    k_1 = 27.8470 N/m
    k_2 = 30.2414 N/m
    k_3 = 30.4965 N/m
    k_4 = 30.2536 N/m
    k_5 = 30.2536 N/m
    k_6 = 30.2563 N/m
    k_7 = 30.6282 N/m
    
